package ar.com.eduit.curso.java.utils.http;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class HttpBody {
    public static String getBody(String url){
        HttpClient client=HttpClient.newHttpClient();
        HttpRequest request=HttpRequest.newBuilder(
                URI.create(url))
                .build();
        try{
            HttpResponse<String>response=client.send(request, HttpResponse.BodyHandlers.ofString());
            return response.body();
        }catch(Exception e){
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
            return "";
        }
    }
}
