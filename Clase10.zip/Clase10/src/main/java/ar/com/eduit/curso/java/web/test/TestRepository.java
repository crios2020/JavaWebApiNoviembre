package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.services.rest.ArticuloRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_ArticuloRepository ar=new ArticuloRepository("http://localhost:8086/Clase09/resources/articulos/v1");
        Articulo articulo=new Articulo("PS5",500000,1);
        ar.save(articulo);
        System.out.println(articulo);
        System.out.println("*************************************************");
        //ar.getAll().forEach(System.out::println);
        //ar.getLikeDescripcion("me").forEach(System.out::println);
    }
}
