package ar.com.eduit.curso.java.web.repositories.services.rest;

import ar.com.eduit.curso.java.utils.http.HttpBody;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;

public class ArticuloRepository implements I_ArticuloRepository {
    String url;

    public ArticuloRepository(String url) {
        this.url = url;
    }
    
    @Override
    public void save(Articulo articulo) {
        if(articulo==null) return;
        String url2=url+"/alta?";
        url2+="descripcion="+articulo.getDescripcion();
        url2+="&precio="+articulo.getPrecio();
        url2+="&stock="+articulo.getStock();
        //System.out.println(url2);
        String resp=HttpBody.getBody(url2);
        try {
            articulo.setId(Integer.parseInt(resp));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Articulo articulo) {
        if(articulo==null) return;
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Articulo articulo) {
        if(articulo==null) return;
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Articulo> getAll() {
        //String url2=url+"/all";
        //String resp=HttpBody.getBody(url2);
        //Type listType=new TypeToken<List<Articulo>>(){}.getType();
        //return new Gson().fromJson(resp,listType);
        return new Gson()
                .fromJson(
                        HttpBody.getBody(url+"/all"),
                        new TypeToken<List<Articulo>>(){}.getType());
    }
    
}
