package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.utils.http.HttpBody;
import ar.com.eduit.curso.java.web.entities.Articulo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class TestService {
    public static void main(String[] args) throws Exception {    
        HttpClient client=HttpClient.newHttpClient();
        HttpRequest request=HttpRequest.newBuilder(
                URI.create("http://localhost:8086/Clase09/resources/articulos/v1/all"))
                .build();
        HttpResponse<String>response=client.send(request, HttpResponse.BodyHandlers.ofString());
        String body= response.body();
        System.out.println(body);
        
        
        Type listType=new TypeToken<List<Articulo>>(){}.getType();
        List<Articulo>list=new Gson().fromJson(body,listType);
        list.forEach(System.out::println);
        
        System.out.println("*************************************************");
        System.out.println(HttpBody.getBody("http://localhost:8086/Clase09/resources/clientes/v1/all"));
        
    }
}
