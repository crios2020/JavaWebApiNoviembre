package ar.com.edit.curso.java.web.clase01;
public class Clase01 {
 /*
 * 	Curso: Java Web API	30hs
 *  Días: Martes y Jueves 10:00 a 13:00 hs
 * 	Profe: Carlos Ríos		carlos.rios@educacionit.com
 * 
 * 	Materiales: alumni.educacionit.com
 * 	github: https://github.com/crios2020/JavaWebApiNoviembre
 * 
 *  Software:
 * 				JDK: 8.X o 11.X
 * 				IDE: (NetBeans, Eclipse, Spring Tools Suite, IntelliJ)
 * 				Servlet Container(JavaEE):	Tomcat, TOMEE, Jetty, GlassFish, Payara 
 * 											WebLogic, JBoss, WebSphere, 
 * 											WildFly, Jenkins, Kassandra
 * 
 */
}
