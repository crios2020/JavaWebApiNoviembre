package ar.com.eduit.curso.java.web.managed.bean;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("articuloMB")
@SessionScoped
public class ArticuloManagedBean implements Serializable {
    private Articulo articulo=new Articulo();
    private String mensaje="";
    private I_ArticuloRepository ar=new ArticuloRepository();

    public void save(){
        try {
            ar.save(articulo);
            if(articulo.getId()>0){
                mensaje="Se dio de alta el ariculo id: "+articulo.getId();
                articulo=new Articulo();
            }else{
                mensaje="No se pudo guardar el objeto";
            }
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
            mensaje="No se pudo guardar el objeto";
        }
    }
    
    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
}
