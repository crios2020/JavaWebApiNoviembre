drop database if exists negocioWeb;
create database negocioWeb;
use negocioWeb;

create table clientes(
    id int primary key auto_increment,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    tipoDocumento enum('DNI','LC','LE','PASS'),
    nroDocumento char(8),
    direccion varchar(100),
    comentarios varchar(255)
);

create table articulos(
    id int primary key auto_increment,
    descripcion varchar(25),
    precio float,
    stock int
);

create table facturas(
    letra enum('A','B','C'),
    nro int,
    fecha date,
    idCliente int not null,
    primary key(letra,nro)
);


alter table facturas 
    add constraint FK_Facturas_idCliente
    foreign key(idCliente)
    references clientes(id);

create table detalles(
    letra enum('A','B','C'),
    nro int,
    idArticulo int,
    cantidad int,
    precioUnit float,
    primary key(letra,nro,idArticulo)
);

alter table detalles
    add constraint FK_Detalles_facturas
    foreign key(letra,nro)
    references facturas(letra,nro);

alter table detalles
    add constraint FK_Detalles_idArticulo
    foreign key(idArticulo)
    references articulos(id);

select * from articulos;