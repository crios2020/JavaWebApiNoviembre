package ar.com.eduit.curso.java.web.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    private static String driver="com.mysql.cj.jdbc.Driver";
    private static String url="jdbc:mysql://localhost:3306/negocioWeb?serverTimezone=UTC";
    private static String user="root";
    private static String pass="";
    
    public static Connection getConnection(){
        try {
            Class.forName(driver);
            return DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
            return null;
        }
    }
}
