package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.web.entities.Persona;
import ar.com.eduit.curso.java.web.entities.repositories.PersonaRepository;
import com.google.gson.Gson;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("cliente/v1")
public class PersonaService {
    
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String info(){
        return "Servicio Cliente Activo";
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("info")
    public String info2(){
        return System.getProperties().toString();
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("alta")
    public String alta( @QueryParam("nombre") String nombre, 
                        @QueryParam("apellido") String apellido,
                        @QueryParam("edad") int edad){
        try {
            if(nombre==null || nombre.isEmpty() 
                    || apellido==null || apellido.isEmpty()
                    || edad<=0) return "false";
            Persona persona=new Persona(nombre,apellido,edad);
            PersonaRepository.save(persona);
            return "true";
        } catch (Exception e) {
            return "false";
        }
    }
    
    @GET
    @Path("all")
    @Produces(MediaType.APPLICATION_JSON)
    public String all(){
        return new Gson().toJson(PersonaRepository.getAll());
    }
    
    
}
