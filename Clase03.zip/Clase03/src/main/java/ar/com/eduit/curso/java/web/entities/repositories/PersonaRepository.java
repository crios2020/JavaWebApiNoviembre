package ar.com.eduit.curso.java.web.entities.repositories;

import ar.com.eduit.curso.java.web.entities.Persona;
import java.util.ArrayList;
import java.util.List;

public class PersonaRepository {
    
    private static List<Persona>list=new ArrayList();
    
    public static void save(Persona persona){
        list.add(persona);
    }
    
    public static void remove(Persona persona){
        list.remove(persona);
    }
    
    public static List<Persona>getAll(){
        return list;
    }
}
