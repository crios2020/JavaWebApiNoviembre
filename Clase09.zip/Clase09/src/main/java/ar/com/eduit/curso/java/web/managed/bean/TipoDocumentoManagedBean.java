package ar.com.eduit.curso.java.web.managed.bean;

import ar.com.eduit.curso.java.web.enums.TipoDocumento;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("tipoDocumentoMB")
@SessionScoped
public class TipoDocumentoManagedBean implements Serializable{
    public List<TipoDocumento> getTipoDocumentos(){
        return Arrays.asList(TipoDocumento.values());
    }
}
