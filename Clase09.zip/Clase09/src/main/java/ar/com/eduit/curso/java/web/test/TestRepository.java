package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.enums.TipoDocumento;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ClienteRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_ArticuloRepository ar=new ArticuloRepository();
        Articulo articulo=new Articulo("Remera",340,60);
        ar.save(articulo);
        System.out.println(articulo);
        System.out.println("*************************************************");
        //ar.getAll().forEach(System.out::println);
        //System.out.println(ar.getById(3));
        ar.getLikeDescripcion("te").forEach(System.out::println);
        
        I_ClienteRepository cr=new ClienteRepository();
        //Cliente cliente=new Cliente("Javier","Mendoza",TipoDocumento.DNI,"12345675","Lima 222","");
        //cr.save(cliente);
        //System.out.println(cliente);
        
        System.out.println("*************************************************");
        //cr.getAll().forEach(System.out::println);
        cr.getLikeApellido("m").forEach(System.out::println);
    }
}
