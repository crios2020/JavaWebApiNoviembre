package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.enums.TipoDocumento;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ClienteRepository;
import com.google.gson.Gson;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("clientes/v1")
public class ClienteServicio {
    private I_ClienteRepository cr=new ClienteRepository();
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio Clientes Activo!";
    }
    
    @GET
    @Path("alta")
    @Produces(MediaType.TEXT_PLAIN)
    public int alta(
            @QueryParam("nombre")String nombre, 
            @QueryParam("apellido")String apellido, 
            @QueryParam("tipoDocumento")String tipoDocumento, 
            @QueryParam("nroDocumento")String nroDocumento, 
            @QueryParam("direccion")String direccion, 
            @QueryParam("comentarios")String comentarios){
        try{
            Cliente cliente=new Cliente(
                    nombre,
                    apellido,
                    TipoDocumento.valueOf(tipoDocumento),
                    nroDocumento,
                    direccion,
                    comentarios
            );
            System.out.println("*********************************************");
            System.out.println(cliente);
            System.out.println("*********************************************");
            cr.save(cliente);
            return cliente.getId();
        }catch(Exception e){
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
            return 0;  
        }
    }
    
        @GET
    @Path("all")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
        return new Gson().toJson(cr.getAll());
    }
    
    @GET
    @Path("likeApellido")
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeDescripcion(@QueryParam("apellido")String apellido){
        return new Gson().toJson(cr.getLikeApellido(apellido));
    }

}
