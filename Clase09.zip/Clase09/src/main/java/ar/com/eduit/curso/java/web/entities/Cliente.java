package ar.com.eduit.curso.java.web.entities;

import ar.com.eduit.curso.java.web.enums.TipoDocumento;

public class Cliente {
    private int id;
    private String nombre;
    private String apellido;
    private TipoDocumento tipoDocumento;
    private String nroDocumento;
    private String direccion;
    private String comentarios;

    public Cliente() {
    }

    public Cliente(String nombre, String apellido, TipoDocumento tipoDocumento, String nroDocumento, String direccion, String comentarios) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipoDocumento = tipoDocumento;
        this.nroDocumento = nroDocumento;
        this.direccion = direccion;
        this.comentarios = comentarios;
    }

    public Cliente(int id, String nombre, String apellido, TipoDocumento tipoDocumento, String nroDocumento, String direccion, String comentarios) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipoDocumento = tipoDocumento;
        this.nroDocumento = nroDocumento;
        this.direccion = direccion;
        this.comentarios = comentarios;
    }

    @Override
    public String toString() {
        return "Cliente{" + "id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", tipoDocumento=" + tipoDocumento + ", nroDocumento=" + nroDocumento + ", direccion=" + direccion + ", comentarios=" + comentarios + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }
    
}
