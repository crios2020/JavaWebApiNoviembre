
package ar.com.eduit.curso.java.adv.entities;

import ar.com.eduit.curso.java.adv.enums.EstadoCivil;

public class Persona {
    private String nombre;
    private String apellido;
    private EstadoCivil estadoCivil;

    public Persona() {
    }

    public Persona(String nombre, String apellido, EstadoCivil estadoCivil) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.estadoCivil = estadoCivil;
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", apellido=" + apellido + ", estadoCivil=" + estadoCivil + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public EstadoCivil getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(EstadoCivil estadoCivil) {
        this.estadoCivil = estadoCivil;
    }
 
}
