package ar.com.eduit.curso.java.adv.managed.bean;

import ar.com.eduit.curso.java.adv.entities.Persona;
import ar.com.eduit.curso.java.adv.repositories.PersonaRepository;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("personaMB")
@SessionScoped
public class PersonaMB implements Serializable{
    private Persona persona=new Persona();
    private PersonaRepository pr=new PersonaRepository();
    private String mensaje="";

    public void save(){
        pr.save(persona);
        mensaje="Se ingreso una persona";
        persona=new Persona();
    }
    
    public List<Persona>getAll(){
        return pr.getAll();
    }
    
    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    
}
