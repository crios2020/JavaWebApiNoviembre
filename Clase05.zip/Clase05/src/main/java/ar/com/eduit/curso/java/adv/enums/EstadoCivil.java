package ar.com.eduit.curso.java.adv.enums;
public enum EstadoCivil { SOLTERO,CASADO,VIUDO,DIVORCIADO,UNIONLIBRE }