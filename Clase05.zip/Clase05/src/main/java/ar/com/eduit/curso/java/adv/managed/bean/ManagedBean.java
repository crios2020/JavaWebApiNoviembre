package ar.com.eduit.curso.java.adv.managed.bean;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("managed")
@SessionScoped
public class ManagedBean implements Serializable{
    private String mensaje="Hola a todos";
    private String nombre="";
    public String getMensaje() {
        return mensaje;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
   
}
