package ar.com.eduit.curso.java.adv.repositories;

import ar.com.eduit.curso.java.adv.entities.Persona;
import java.util.ArrayList;
import java.util.List;

public class PersonaRepository {
    private List<Persona>lista=new ArrayList();
    
    public void save(Persona persona){
        lista.add(persona);
    }
    
    public List<Persona>getAll(){
        return lista;
    }
}
