package ar.com.eduit.curso.java.web.repositories.jdbc;

import ar.com.eduit.curso.java.web.connectors.Connector;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

public class ClienteRepository implements I_ClienteRepository{
    Connection conn=Connector.getConnection();

    @Override
    public void save(Cliente cliente) {
        if(cliente==null) return;
        
        /*
        String query="insert into clientes (nombre,apellido,tipoDocumento,nroDocumento,direccion,comentarios) "
                + "values ('"+cliente.getNombre()+"','"+cliente.getApellido()+"','"
                +cliente.getTipoDocumento()+"','"+cliente.getNroDocumento()+"','"
                +cliente.getDireccion()+"','"+cliente.getComentarios()+"')";
        
                // x'); delete from clientes; -- 
        
        try {
            Statement st=conn.createStatement();
            st.execute(query);
        } catch (Exception e) {
        }
        */
        
        try ( PreparedStatement ps=conn.prepareStatement(
                "insert into clientes "
                        + "(nombre,apellido,tipoDocumento,nroDocumento,direccion,comentarios) "
                        + "values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS) ){
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getApellido());
            ps.setString(3, cliente.getTipoDocumento().toString());
            ps.setString(4, cliente.getNroDocumento());
            ps.setString(5, cliente.getDireccion());
            ps.setString(6, cliente.getComentarios());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) cliente.setId(rs.getInt(1));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void remove(Cliente cliente) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Cliente cliente) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Cliente> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}