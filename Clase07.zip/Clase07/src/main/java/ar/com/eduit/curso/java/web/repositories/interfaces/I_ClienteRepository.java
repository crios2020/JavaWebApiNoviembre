package ar.com.eduit.curso.java.web.repositories.interfaces;

import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.enums.TipoDocumento;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_ClienteRepository {
    void save(Cliente cliente);
    void remove(Cliente cliente);
    void update(Cliente cliente);
    List<Cliente>getAll();
    default Cliente getById(int id){
        return getAll()
                .stream()
                .filter(c->c.getId()==id)
                .findAny()
                .orElse(new Cliente());
    }
    default List<Cliente>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList<Cliente>();
        return getAll()
                .stream()
                .filter(c->c.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
    default Cliente getByDocumento(TipoDocumento tipo,String nroDocumento){
        if(tipo==null || nroDocumento==null) return new Cliente();
        return getAll()
                .stream()
                .filter(c->c.getTipoDocumento()==tipo && c.getNroDocumento().equals(nroDocumento))
                .findAny()
                .orElse(new Cliente());
    }
}