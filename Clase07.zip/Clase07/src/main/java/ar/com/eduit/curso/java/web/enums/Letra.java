package ar.com.eduit.curso.java.web.enums;
public enum Letra { A,B,C }