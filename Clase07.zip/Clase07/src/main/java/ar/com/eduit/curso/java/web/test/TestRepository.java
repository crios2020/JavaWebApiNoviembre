package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_ArticuloRepository ar=new ArticuloRepository();
        Articulo articulo=new Articulo("Remera",340,60);
        //ar.save(articulo);
        System.out.println(articulo);
        System.out.println("*************************************************");
        ar.getAll().forEach(System.out::println);
        //System.out.println(ar.getById(3));
        //ar.getLikeDescripcion("tenis").forEach(System.out::println);
    }
}
