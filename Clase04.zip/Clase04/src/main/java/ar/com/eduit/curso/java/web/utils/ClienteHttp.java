package ar.com.eduit.curso.java.web.utils;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ClienteHttp {
    public static String response(String url){
        HttpClient client=HttpClient.newHttpClient();
        HttpRequest req=HttpRequest
                    .newBuilder()
                    .uri(URI.create(url)).build();
        
        HttpResponse<String>resp=null;
        try {
            resp=client.send(req,
                    HttpResponse.BodyHandlers.ofString());
        } catch (Exception ex) {
        }
        return resp.body();
    }
}
