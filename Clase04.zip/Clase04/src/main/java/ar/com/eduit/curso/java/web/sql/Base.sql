drop database if exists clientes;
create database clientes;
use clientes;

create table personas(
    nombre varchar(25),
    apellido varchar(25),
    edad int
);

select * from personas;
