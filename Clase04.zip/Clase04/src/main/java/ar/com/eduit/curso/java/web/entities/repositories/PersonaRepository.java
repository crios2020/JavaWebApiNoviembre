package ar.com.eduit.curso.java.web.entities.repositories;

import ar.com.eduit.curso.java.web.entities.Persona;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PersonaRepository {
    
    //private static List<Persona>list=new ArrayList();
    private static Connection conn=getConnection();
    
    private static Connection getConnection(){
        Connection conn=null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/clientes?serverTimezone=UTC","root","");
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
        return conn;
    }
    
    public static void save(Persona persona){
        try (PreparedStatement ps=conn.prepareStatement(
                "insert into personas (nombre,apellido,edad) values (?,?,?)")) {
            ps.setString(1, persona.getNombre());
            ps.setString(2, persona.getApellido());
            ps.setInt(3, persona.getEdad());
            ps.execute();
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
    }
    
    public static void remove(Persona persona){
        //list.remove(persona);
    }
    
    public static List<Persona>getAll(){
        List<Persona>list=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from personas")){
            while(rs.next()){
                list.add(new Persona(
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("edad")
                ));
            }
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
        return list;
    }
}
